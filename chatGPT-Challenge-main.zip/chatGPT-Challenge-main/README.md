# تحدي جديد! في مجال جديد!
شاركنا بتحدي مسار  chatGPT" في موقعك الخاص" قم بتحديد مجال خبرة chatGPT في موقعك وقم بتعبئة الأسطر الناقصة (TODO) وعدل واجهة المستخدم بما يتناسب فكرتك!

<h1>للمشاركة في التحدي اتبع الخطوات التالية:</h1>
<h3>1- قم بتحديد المجال الذي تود ان يكون chatGPT خبير فيه</h3>
<h5>(مجال الفضاء، مجال التغذية وغيرها من المجالات)</h5>

<h3>2- اضغط على زر Fork</h3>

![1](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/d13ce6ba-3d04-4b92-9073-8edf5a967caf)

<h3>3- قم بتأكيد البيانات ثم اضغط على Fork</h3>

![2](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/54e291fa-fdf5-4016-a8b6-7a7b750f69fc)

<h3>4- سيتم انشاء نسخة جديدة من المشروع وستظهر في حسابك الشخصي </h3>

![3](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/fd9213e8-c7b8-4338-8cb4-c6148ff4d290)

<h3>5- قم بتنزيل المشروع على جهازك الخاص </h3>

![4](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/679debd4-f4d9-4c81-a057-ef48bb150825)

<h3>6- افتح المجلد لاستكشاف الملفات </h3>
<h5>حيث ستجد 3 ملفات مختلفة ومجلد يحتوى على صور</h5>

![5](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/ea97af2f-9b8e-4920-8e72-cd504df8d176)

<h3>7- اضغط على ملف Masar'sbot.html ليفتح على متصفحك</h3>

![6](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/53789b72-652d-48fa-b4bd-600016f9da0a)

<h3>8- ابحث عن المهام وقم بتنفيزها</h3>
<h5>ابحث عن كلمة TODO او التعليقات وقم بتنفيذ ما كتب في التعليقات</h5>

![7](https://github.com/masargroup/chatGPT-Challenge/assets/102878670/7586d92e-0ce4-4c9e-95e0-3eb04320edaa)

<h3>شاركنا انجازك</h3>
<h5> 9- قم برفع المشروع على GitHub او قم بمشاركة صور له مع ذكر تجربتك خلال منصات التواصل الاجتماعي قم بإرفاق هاشتاق #مبادرة_مسار و #تحديات_مسار بالإضافة الى عمل منشن لحساب مسار لتكون ضمن مجتمع مسار الإبداعي ولتشاركنا انجازك </h5>


